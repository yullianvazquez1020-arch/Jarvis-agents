"""Personal Agent: everyday-life helper. Reminders, shopping list, bills,
and general questions. Plain language in."""
import os, json, datetime
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Personal Agent")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
API_KEY = os.getenv("AGENT_API_KEY", "change-me")
DB = "personal.json"

def _load():
    return json.load(open(DB)) if os.path.exists(DB) else {"reminders": [], "shopping": [], "bills": []}
def _save(d): json.dump(d, open(DB, "w"), ensure_ascii=False, indent=2)

def add_reminder(text, when=""):
    d=_load(); d["reminders"].append({"text":text,"when":when,"done":False}); _save(d); return {"reminder":text,"when":when}
def add_shopping(item):
    d=_load(); d["shopping"].append(item); _save(d); return {"shopping":d["shopping"]}
def clear_shopping():
    d=_load(); d["shopping"]=[]; _save(d); return {"shopping":[]}
def add_bill(name, day, amount=""):
    d=_load(); d["bills"].append({"name":name,"day":day,"amount":amount}); _save(d); return {"bill":name,"day":day}
def overview(): return _load()

HANDLERS={"add_reminder":add_reminder,"add_shopping":add_shopping,"clear_shopping":clear_shopping,
          "add_bill":add_bill,"overview":overview}
TOOLS=[
 {"name":"add_reminder","description":"Add a reminder.","input_schema":{"type":"object","properties":{"text":{"type":"string"},"when":{"type":"string"}},"required":["text"]}},
 {"name":"add_shopping","description":"Add one item to the shopping list.","input_schema":{"type":"object","properties":{"item":{"type":"string"}},"required":["item"]}},
 {"name":"clear_shopping","description":"Empty the shopping list.","input_schema":{"type":"object","properties":{}}},
 {"name":"add_bill","description":"Track a recurring bill by day of month.","input_schema":{"type":"object","properties":{"name":{"type":"string"},"day":{"type":"integer"},"amount":{"type":"string"}},"required":["name","day"]}},
 {"name":"overview","description":"Return all reminders, shopping list and bills.","input_schema":{"type":"object","properties":{}}},
]
SYSTEM=("You are a personal life assistant. Use the tools to keep reminders, a shopping list and bills. "
        "For general questions, just answer. Be brief and warm. Reply in the user's language (Spanish by default).")

def run_agent(message):
    now=datetime.datetime.now().astimezone().isoformat()
    messages=[{"role":"user","content":message}]
    for _ in range(8):
        r=client.messages.create(model=MODEL,max_tokens=1200,system=SYSTEM+f" Now: {now}.",tools=TOOLS,messages=messages)
        if r.stop_reason!="tool_use":
            return "".join(b.text for b in r.content if b.type=="text")
        messages.append({"role":"assistant","content":r.content})
        results=[]
        for b in r.content:
            if b.type=="tool_use":
                try: out=HANDLERS[b.name](**b.input)
                except Exception as e: out={"error":str(e)}
                results.append({"type":"tool_result","tool_use_id":b.id,"content":json.dumps(out,default=str,ensure_ascii=False)})
        messages.append({"role":"user","content":results})
    return "Demasiados pasos. Dimelo mas simple?"

class Ask(BaseModel):
    message: str

@app.post("/ask")
async def ask(req: Ask, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    return {"reply": run_agent(req.message)}
