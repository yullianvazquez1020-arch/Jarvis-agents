"""Coinbase Agent: watch the market, read your portfolio, and PREPARE orders.
IT NEVER PLACES A TRADE BY ITSELF. Every buy/sell is returned as a prepared
order for YOU to approve and execute. Analysis and market data are unlimited.

Uses the Coinbase Advanced Trade API via the coinbase-advanced-py SDK.
Give the API key READ-ONLY permissions and you physically cannot trade from here.
"""
import os, json, datetime
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Coinbase Agent (watch & advise)")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
API_KEY = os.getenv("AGENT_API_KEY", "change-me")

# Coinbase SDK is imported lazily so the agent still boots for pure analysis
def cb():
    from coinbase.rest import RESTClient
    return RESTClient(api_key=os.environ["COINBASE_API_KEY"],
                      api_secret=os.environ["COINBASE_API_SECRET"])

# ---------------- read-only market + account tools ----------------
def get_price(product_id: str):
    p = cb().get_product(product_id)
    return {"product": product_id, "price": getattr(p, "price", None),
            "24h_change": getattr(p, "price_percentage_change_24h", None),
            "volume_24h": getattr(p, "volume_24h", None)}

def get_candles(product_id: str, granularity: str = "ONE_HOUR", limit: int = 50):
    import time
    end = int(time.time()); start = end - limit * 3600
    c = cb().get_candles(product_id=product_id, start=str(start), end=str(end), granularity=granularity)
    out = []
    for k in getattr(c, "candles", [])[:limit]:
        out.append({"t": getattr(k, "start", None), "o": getattr(k, "open", None),
                    "h": getattr(k, "high", None), "l": getattr(k, "low", None),
                    "c": getattr(k, "close", None), "v": getattr(k, "volume", None)})
    return out

def get_portfolio():
    accts = cb().get_accounts()
    out = []
    for a in getattr(accts, "accounts", []):
        bal = getattr(a, "available_balance", {})
        val = bal.get("value") if isinstance(bal, dict) else getattr(bal, "value", None)
        cur = bal.get("currency") if isinstance(bal, dict) else getattr(bal, "currency", None)
        if val and float(val) > 0:
            out.append({"currency": cur, "balance": val})
    return out

def prepare_order(side: str, product_id: str, amount: str, order_type: str = "market"):
    """Return a prepared order for the OWNER to approve. Does NOT execute."""
    return {"ACTION_REQUIRED": "Review and approve in your Coinbase app or confirm to execute.",
            "prepared_order": {"side": side.upper(), "product_id": product_id,
                               "amount": amount, "type": order_type,
                               "prepared_at": datetime.datetime.now().isoformat()},
            "note": "This agent prepared the order only. No trade has been placed."}

HANDLERS = {"get_price": get_price, "get_candles": get_candles,
            "get_portfolio": get_portfolio, "prepare_order": prepare_order}
TOOLS = [
 {"name":"get_price","description":"Current price and 24h change for a product like BTC-USD.",
  "input_schema":{"type":"object","properties":{"product_id":{"type":"string"}},"required":["product_id"]}},
 {"name":"get_candles","description":"Recent OHLC candles for technical analysis.",
  "input_schema":{"type":"object","properties":{"product_id":{"type":"string"},
                  "granularity":{"type":"string"},"limit":{"type":"integer"}},"required":["product_id"]}},
 {"name":"get_portfolio","description":"Your current balances on Coinbase.",
  "input_schema":{"type":"object","properties":{}}},
 {"name":"prepare_order","description":"Prepare a buy/sell order for the owner to approve. Never executes.",
  "input_schema":{"type":"object","properties":{"side":{"type":"string","enum":["buy","sell"]},
                  "product_id":{"type":"string"},"amount":{"type":"string"},
                  "order_type":{"type":"string"}},"required":["side","product_id","amount"]}},
]
SYSTEM = ("You are a crypto trading analyst for the owner's Coinbase account. "
          "Give unlimited market analysis, read the portfolio, and when the owner wants to act, "
          "use prepare_order to lay out the trade. You NEVER place a trade yourself; the owner "
          "approves and executes every order. Always state risk plainly and never promise profits. "
          "Reply in the user's language (Spanish by default).")

def run_agent(message: str) -> str:
    messages = [{"role": "user", "content": message}]
    for _ in range(10):
        r = client.messages.create(model=MODEL, max_tokens=1800, system=SYSTEM, tools=TOOLS, messages=messages)
        if r.stop_reason != "tool_use":
            return "".join(b.text for b in r.content if b.type == "text")
        messages.append({"role": "assistant", "content": r.content})
        results = []
        for b in r.content:
            if b.type == "tool_use":
                try: out = HANDLERS[b.name](**b.input)
                except Exception as e: out = {"error": str(e)}
                results.append({"type": "tool_result", "tool_use_id": b.id,
                                "content": json.dumps(out, default=str, ensure_ascii=False)[:15000]})
        messages.append({"role": "user", "content": results})
    return "Demasiados pasos."

class Ask(BaseModel):
    message: str

@app.post("/ask")
async def ask(req: Ask, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    return {"reply": run_agent(req.message)}
