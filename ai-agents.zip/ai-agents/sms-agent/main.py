"""SMS + WhatsApp Agent: replies to texts automatically with Twilio + Claude.
Same webhook handles SMS and WhatsApp (WhatsApp numbers start with 'whatsapp:')."""
import os
from fastapi import FastAPI, Form, Header, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from twilio.rest import Client as Twilio
from twilio.twiml.messaging_response import MessagingResponse
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="SMS & WhatsApp Agent")
client = Anthropic()
twilio = Twilio(os.environ["TWILIO_ACCOUNT_SID"], os.environ["TWILIO_AUTH_TOKEN"])
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
BUSINESS = os.getenv("BUSINESS_NAME", "our company")
SMS_FROM = os.getenv("TWILIO_SMS_NUMBER")
WA_FROM = os.getenv("TWILIO_WHATSAPP_NUMBER")  # e.g. whatsapp:+14155238886
API_KEY = os.getenv("AGENT_API_KEY", "change-me")

SYSTEM = f"""You answer text messages for {BUSINESS}.
Keep replies short (under 300 characters), friendly, in the sender's language.
Collect name, reason, and best time to talk when relevant.
Never invent prices or confirm appointments; say the team will confirm."""

history: dict[str, list] = {}


@app.post("/sms")
async def incoming(From: str = Form(...), Body: str = Form("")):
    convo = history.setdefault(From, [])
    convo.append({"role": "user", "content": Body})
    convo[:] = convo[-20:]  # keep last 20 messages
    if convo[0]["role"] != "user":
        convo.pop(0)
    r = client.messages.create(model=MODEL, max_tokens=300, system=SYSTEM, messages=convo)
    reply = "".join(b.text for b in r.content if b.type == "text").strip()
    convo.append({"role": "assistant", "content": reply})
    tw = MessagingResponse()
    tw.message(reply)
    return Response(str(tw), media_type="application/xml")


class Outbound(BaseModel):
    to: str          # +1787... or whatsapp:+1787...
    message: str


@app.post("/send")
async def send(msg: Outbound, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    sender = WA_FROM if msg.to.startswith("whatsapp:") else SMS_FROM
    m = twilio.messages.create(from_=sender, to=msg.to, body=msg.message)
    return {"sid": m.sid, "status": m.status}


@app.get("/conversations")
async def conversations(x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    return history
