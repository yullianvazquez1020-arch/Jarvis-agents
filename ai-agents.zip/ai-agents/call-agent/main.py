"""Call Agent: answers phone calls with Twilio Voice + Claude.
Collects caller info, answers questions, logs a summary of every call."""
import os, json, datetime
from fastapi import FastAPI, Form
from fastapi.responses import Response
from twilio.twiml.voice_response import VoiceResponse, Gather
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Call Agent")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
BUSINESS = os.getenv("BUSINESS_NAME", "our company")
LANG = os.getenv("VOICE_LANG", "es-US")  # es-US or en-US
GREETING = os.getenv("GREETING", f"Hola, gracias por llamar a {BUSINESS}. ¿En qué le puedo ayudar?")

SYSTEM = f"""You are the phone receptionist for {BUSINESS}.
Rules:
- Reply in 1-2 short sentences; this is spoken aloud.
- Speak the caller's language (Spanish or English).
- Collect: name, callback number, reason for the call, preferred time.
- For quotes or appointments, gather the details and say the team will confirm.
- Never invent prices, availability, or promises.
- When the caller is done, say goodbye and end your message with [END]."""

sessions: dict[str, list] = {}


def xml(vr: VoiceResponse) -> Response:
    return Response(str(vr), media_type="application/xml")


def speak_and_listen(text: str) -> VoiceResponse:
    vr = VoiceResponse()
    g = Gather(input="speech", action="/voice/respond", method="POST",
               speech_timeout="auto", language=LANG)
    g.say(text, language=LANG)
    vr.append(g)
    vr.say("No le escuché. Puede llamar de nuevo cuando guste. Adiós.", language=LANG)
    vr.hangup()
    return vr


@app.post("/voice/incoming")
async def incoming(CallSid: str = Form(...), From: str = Form("")):
    sessions[CallSid] = [{"role": "assistant", "content": GREETING}]
    return xml(speak_and_listen(GREETING))


@app.post("/voice/respond")
async def respond(CallSid: str = Form(...), SpeechResult: str = Form("")):
    history = sessions.setdefault(CallSid, [{"role": "assistant", "content": GREETING}])
    history.append({"role": "user", "content": SpeechResult or "(silence)"})
    # Claude requires the first message to be from the user
    msgs = [{"role": "user", "content": "(call connected)"}] + history
    r = client.messages.create(model=MODEL, max_tokens=200, system=SYSTEM, messages=msgs)
    reply = "".join(b.text for b in r.content if b.type == "text").strip()
    history.append({"role": "assistant", "content": reply})

    if "[END]" in reply:
        vr = VoiceResponse()
        vr.say(reply.replace("[END]", "").strip(), language=LANG)
        vr.hangup()
        return xml(vr)
    return xml(speak_and_listen(reply))


@app.post("/voice/status")
async def status(CallSid: str = Form(...), CallStatus: str = Form(""), From: str = Form("")):
    """Twilio status callback: when the call ends, save a summary."""
    if CallStatus == "completed" and CallSid in sessions:
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in sessions.pop(CallSid))
        r = client.messages.create(
            model=MODEL, max_tokens=400,
            messages=[{"role": "user", "content":
                       "Summarize this call as JSON with keys name, phone, reason, "
                       f"preferred_time, follow_up_needed. Transcript:\n{transcript}"}])
        summary = "".join(b.text for b in r.content if b.type == "text")
        with open("calls.jsonl", "a") as f:
            f.write(json.dumps({"time": datetime.datetime.now().isoformat(), "from": From,
                                "summary": summary, "transcript": transcript}) + "\n")
    return {"ok": True}


@app.get("/calls")
async def calls():
    if not os.path.exists("calls.jsonl"):
        return []
    with open("calls.jsonl") as f:
        return [json.loads(line) for line in f]
