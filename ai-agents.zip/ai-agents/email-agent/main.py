"""Email Agent: reads unread Gmail, decides if a reply is needed,
writes the reply with Claude, and saves it as a DRAFT (or sends if AUTO_SEND=true)."""
import os, json, base64
from email.message import EmailMessage
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Email Agent")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
BUSINESS = os.getenv("BUSINESS_NAME", "our company")
SIGNATURE = os.getenv("SIGNATURE", f"\n\n— {BUSINESS}")
AUTO_SEND = os.getenv("AUTO_SEND", "false").lower() == "true"
API_KEY = os.getenv("AGENT_API_KEY", "change-me")
SCOPES = ["https://www.googleapis.com/auth/gmail.modify"]


def gmail():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def get_body(payload) -> str:
    if payload.get("mimeType") == "text/plain" and payload.get("body", {}).get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", "ignore")
    for part in payload.get("parts", []) or []:
        text = get_body(part)
        if text:
            return text
    return ""


def header(msg, name):
    return next((h["value"] for h in msg["payload"]["headers"] if h["name"].lower() == name.lower()), "")


def think(sender, subject, body) -> dict:
    prompt = f"""You handle email for {BUSINESS}. Read this email and return ONLY JSON:
{{"needs_reply": true/false, "category": "lead|client|vendor|spam|newsletter|other",
  "summary": "one sentence", "reply": "the reply text, same language as the email"}}
Do not reply to spam, newsletters or automated notifications. Never invent prices.

From: {sender}
Subject: {subject}
Body:
{body[:6000]}"""
    r = client.messages.create(model=MODEL, max_tokens=1000, messages=[{"role": "user", "content": prompt}])
    text = "".join(b.text for b in r.content if b.type == "text")
    text = text.replace("```json", "").replace("```", "").strip()
    return json.loads(text)


def build_raw(to, subject, body, msg_id=None):
    m = EmailMessage()
    m["To"] = to
    m["Subject"] = subject if subject.lower().startswith("re:") else f"Re: {subject}"
    if msg_id:
        m["In-Reply-To"] = msg_id
        m["References"] = msg_id
    m.set_content(body + SIGNATURE)
    return base64.urlsafe_b64encode(m.as_bytes()).decode()


def process_inbox(limit: int = 10):
    svc = gmail()
    res = svc.users().messages().list(userId="me", q="is:unread in:inbox", maxResults=limit).execute()
    report = []
    for item in res.get("messages", []):
        msg = svc.users().messages().get(userId="me", id=item["id"], format="full").execute()
        sender, subject = header(msg, "From"), header(msg, "Subject")
        try:
            result = think(sender, subject, get_body(msg["payload"]))
        except Exception as e:
            report.append({"subject": subject, "error": str(e)})
            continue
        action = "skipped"
        if result.get("needs_reply"):
            raw = build_raw(sender, subject, result["reply"], header(msg, "Message-ID"))
            body = {"raw": raw, "threadId": msg["threadId"]}
            if AUTO_SEND:
                svc.users().messages().send(userId="me", body=body).execute()
                action = "sent"
            else:
                svc.users().drafts().create(userId="me", body={"message": body}).execute()
                action = "draft_created"
        svc.users().messages().modify(userId="me", id=item["id"],
                                      body={"removeLabelIds": ["UNREAD"]}).execute()
        report.append({"from": sender, "subject": subject, "category": result.get("category"),
                       "summary": result.get("summary"), "action": action})
    return report


class NewEmail(BaseModel):
    to: str
    subject: str
    body: str


@app.post("/process-inbox")
async def run(limit: int = 10, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    return process_inbox(limit)


@app.post("/send")
async def send(email: NewEmail, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    m = EmailMessage()
    m["To"], m["Subject"] = email.to, email.subject
    m.set_content(email.body + SIGNATURE)
    raw = base64.urlsafe_b64encode(m.as_bytes()).decode()
    sent = gmail().users().messages().send(userId="me", body={"raw": raw}).execute()
    return {"id": sent["id"]}


if __name__ == "__main__":
    # Run once from the terminal: python main.py
    print(json.dumps(process_inbox(), indent=2, ensure_ascii=False))
