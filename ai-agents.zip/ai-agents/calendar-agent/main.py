"""Calendar Agent: manage Google Calendar in plain language.
POST /ask {"message": "Ponme una visita con Juan el martes a las 10am en Bayamón"}"""
import os, json, datetime
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Calendar Agent")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
TZ = os.getenv("TIMEZONE", "America/Puerto_Rico")
CAL_ID = os.getenv("CALENDAR_ID", "primary")
API_KEY = os.getenv("AGENT_API_KEY", "change-me")
SCOPES = ["https://www.googleapis.com/auth/calendar"]


def cal():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            creds = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES).run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return build("calendar", "v3", credentials=creds)


# ---------- tools ----------
def list_events(start: str, end: str):
    items = cal().events().list(calendarId=CAL_ID, timeMin=start, timeMax=end,
                                singleEvents=True, orderBy="startTime").execute().get("items", [])
    return [{"id": e["id"], "title": e.get("summary"), "start": e["start"].get("dateTime", e["start"].get("date")),
             "end": e["end"].get("dateTime", e["end"].get("date")), "location": e.get("location")} for e in items]


def create_event(title: str, start: str, end: str, location: str = "", description: str = "", attendees: list = None):
    body = {"summary": title, "location": location, "description": description,
            "start": {"dateTime": start, "timeZone": TZ}, "end": {"dateTime": end, "timeZone": TZ}}
    if attendees:
        body["attendees"] = [{"email": a} for a in attendees]
    e = cal().events().insert(calendarId=CAL_ID, body=body, sendUpdates="all").execute()
    return {"id": e["id"], "link": e.get("htmlLink")}


def update_event(event_id: str, title: str = None, start: str = None, end: str = None, location: str = None):
    svc = cal()
    e = svc.events().get(calendarId=CAL_ID, eventId=event_id).execute()
    if title: e["summary"] = title
    if location: e["location"] = location
    if start: e["start"] = {"dateTime": start, "timeZone": TZ}
    if end: e["end"] = {"dateTime": end, "timeZone": TZ}
    svc.events().update(calendarId=CAL_ID, eventId=event_id, body=e, sendUpdates="all").execute()
    return {"updated": event_id}


def delete_event(event_id: str):
    cal().events().delete(calendarId=CAL_ID, eventId=event_id, sendUpdates="all").execute()
    return {"deleted": event_id}


HANDLERS = {"list_events": list_events, "create_event": create_event,
            "update_event": update_event, "delete_event": delete_event}
ISO = {"type": "string", "description": "ISO 8601 datetime with offset, e.g. 2026-10-06T10:00:00-04:00"}
TOOLS = [
    {"name": "list_events", "description": "List events between two datetimes.",
     "input_schema": {"type": "object", "properties": {"start": ISO, "end": ISO}, "required": ["start", "end"]}},
    {"name": "create_event", "description": "Create an event. Default length 1 hour if not stated.",
     "input_schema": {"type": "object", "properties": {"title": {"type": "string"}, "start": ISO, "end": ISO,
                      "location": {"type": "string"}, "description": {"type": "string"},
                      "attendees": {"type": "array", "items": {"type": "string"}}},
                      "required": ["title", "start", "end"]}},
    {"name": "update_event", "description": "Change an existing event (find its id with list_events first).",
     "input_schema": {"type": "object", "properties": {"event_id": {"type": "string"}, "title": {"type": "string"},
                      "start": ISO, "end": ISO, "location": {"type": "string"}}, "required": ["event_id"]}},
    {"name": "delete_event", "description": "Delete an event by id (find it with list_events first).",
     "input_schema": {"type": "object", "properties": {"event_id": {"type": "string"}}, "required": ["event_id"]}},
]


def run_agent(message: str) -> str:
    now = datetime.datetime.now().astimezone().isoformat()
    system = (f"You manage the user's calendar. Now is {now}, timezone {TZ}. "
              "Check for conflicts with list_events before creating. Reply briefly in the user's language.")
    messages = [{"role": "user", "content": message}]
    for _ in range(8):
        r = client.messages.create(model=MODEL, max_tokens=1500, system=system, tools=TOOLS, messages=messages)
        if r.stop_reason != "tool_use":
            return "".join(b.text for b in r.content if b.type == "text")
        messages.append({"role": "assistant", "content": r.content})
        results = []
        for b in r.content:
            if b.type == "tool_use":
                try:
                    out = HANDLERS[b.name](**b.input)
                except Exception as e:
                    out = {"error": str(e)}
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": json.dumps(out, default=str)})
        messages.append({"role": "user", "content": results})
    return "Stopped: too many steps."


class Ask(BaseModel):
    message: str


@app.post("/ask")
async def ask(req: Ask, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    return {"reply": run_agent(req.message)}


@app.get("/events")
async def events(days: int = 7, x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(401, "Bad API key")
    now = datetime.datetime.now(datetime.timezone.utc)
    return list_events(now.isoformat(), (now + datetime.timedelta(days=days)).isoformat())


if __name__ == "__main__":
    while True:
        print(run_agent(input("> ")))
