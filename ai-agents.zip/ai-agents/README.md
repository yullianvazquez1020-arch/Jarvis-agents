# AI Agents (5 independent projects)

| Agent | What it does | Needs |
|---|---|---|
| call-agent | Answers phone calls, takes messages, logs summaries | Twilio phone number |
| sms-agent | Auto-replies to SMS and WhatsApp | Twilio (+ WhatsApp sender) |
| email-agent | Reads Gmail, writes replies as drafts | Google Cloud project, Gmail API |
| calendar-agent | Create/move/delete events in plain language | Google Cloud project, Calendar API |
| amazon-agent | Orders, inventory, pricing, product research | Amazon SP-API developer approval |

## Run any agent
```bash
cd call-agent            # or any other folder
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env     # fill in your keys
uvicorn main:app --reload --port 8000
```

## Setup per agent
**call-agent** – In Twilio, set your number's Voice webhook to `https://YOUR-URL/voice/incoming` (POST) and the Status Callback to `https://YOUR-URL/voice/status`. For local testing use `ngrok http 8000`.

**sms-agent** – Set the number's Messaging webhook (and the WhatsApp sandbox webhook) to `https://YOUR-URL/sms`.

**email-agent / calendar-agent** – In Google Cloud Console: create a project, enable the Gmail API (or Calendar API), create an OAuth Client ID of type *Desktop app*, download it as `credentials.json` into the folder. Run `python main.py` once to log in; it creates `token.json`.
Email replies are saved as **drafts** by default. Set `AUTO_SEND=true` only once you trust it.

**amazon-agent** – Register as a developer in Seller Central (Apps & Services → Develop Apps), create an app, authorize it for your store to get the refresh token. Note: SP-API is for the *selling* side. Amazon has no public API for automated buying.

## Calling the protected endpoints
```bash
curl -X POST http://localhost:8000/ask -H "x-api-key: YOUR_KEY" \
  -H "Content-Type: application/json" -d '{"message":"¿Qué tengo mañana?"}'
```

## Before going live
- Conversation history is kept in memory; it resets on restart. Swap in a database (e.g. SQLite/Postgres) for production.
- Never commit `.env`, `credentials.json` or `token.json`.
- Deploy each folder separately (Railway, Render, Fly.io, a VPS…).
