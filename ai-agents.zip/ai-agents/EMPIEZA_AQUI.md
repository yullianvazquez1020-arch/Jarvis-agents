# EMPIEZA AQUI — Jarvis + tus agentes

**Jarvis** es el agente jefe. Tu le hablas a Jarvis desde tu iPhone (por Telegram),
y el le da ordenes a los agentes especialistas y te trae las respuestas.

## El equipo
| Carpeta | Rol |
|---|---|
| **jarvis** | El coordinador con quien hablas. Reparte el trabajo. |
| personal-agent | Vida diaria: recordatorios, lista de compra, biles, preguntas. |
| call-agent | Contesta llamadas. |
| sms-agent | Responde SMS y WhatsApp. |
| email-agent | Lee Gmail, prepara borradores de respuesta. |
| calendar-agent | Crea/mueve/borra eventos del calendario. |
| amazon-agent | Tienda de Amazon: ordenes, inventario, precios, investigacion. |
| coinbase-agent | Cripto: analiza el mercado y PREPARA ordenes. Tu las apruebas. |

## IMPORTANTE sobre dinero
- **coinbase-agent** y **amazon-agent** NUNCA compran ni venden solos.
  Te preparan la orden y TU la apruebas y ejecutas. Esa es la regla.
- Para Coinbase, crea la API key en modo **solo lectura**: asi es
  fisicamente imposible que se haga un trade desde el agente. Analisis sin limite;
  ejecucion, solo con tu mano.

## Arrancar HOY desde el iPhone (sin computadora)
No necesitas todos los agentes vivos para empezar: Jarvis + personal-agent basta
para sentirlo funcionar. Todo corre en un servidor; tu iPhone es el control remoto.

1. **GitHub** (en el navegador del telefono): crea cuenta gratis, crea un repo
   nuevo, sube esta carpeta completa (GitHub deja subir archivos desde el navegador).
2. **Render o Railway** (en el navegador): registrate, "New Web Service", conecta
   el repo, escoge la carpeta `jarvis`.
   - Build: `pip install -r requirements.txt`
   - Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - Agrega las variables de `jarvis/.env.example` (pega tus llaves).
   - Deploy. Te da una URL como `https://jarvis-xxxx.onrender.com`.
3. **Telegram** (app en el iPhone): abre @BotFather, manda `/newbot`, sigue los
   pasos, copia el **token** en `TELEGRAM_BOT_TOKEN`. Tu ID numerico lo da
   @userinfobot; ponlo en `TELEGRAM_OWNER_ID`.
4. **Conecta el webhook** — abre esto una vez en el navegador (con tus datos):
   `https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://jarvis-xxxx.onrender.com/telegram`
5. **Hablale a Jarvis** desde el chat de tu bot en Telegram. Listo.

Repite el paso 2 por cada agente que quieras vivo, y pega cada URL en las
variables de Jarvis (PERSONAL_AGENT_URL, etc.) y vuelve a deployar Jarvis.

## Notas
- Usa la **misma** `AGENT_API_KEY` en todos para que Jarvis pueda llamarlos.
- Render gratis se duerme al rato; un plan de $5-7/mes lo mantiene despierto.
- Los de Google (email, calendario) piden un login de Google que es mas facil
  en computadora; esos los dejas para cuando tengas la Mac. Jarvis corre sin ellos.
