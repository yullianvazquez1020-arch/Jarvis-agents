"""Amazon Seller Agent: ask questions about your Amazon store in plain language.
Uses the Selling Partner API (SP-API). Requires an approved SP-API developer app.
POST /ask {"message": "¿Cuántas órdenes tuve esta semana y qué producto se vendió más?"}"""
import os, json, datetime
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from sp_api.api import Orders, Inventories, Products, CatalogItems
from sp_api.base import Marketplaces
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Amazon Seller Agent")
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
API_KEY = os.getenv("AGENT_API_KEY", "change-me")
MP = getattr(Marketplaces, os.getenv("MARKETPLACE", "US"))
CREDS = {
    "refresh_token": os.getenv("SP_API_REFRESH_TOKEN"),
    "lwa_app_id": os.getenv("LWA_APP_ID"),
    "lwa_client_secret": os.getenv("LWA_CLIENT_SECRET"),
}


# ---------- tools ----------
def get_orders(days: int = 7):
    after = (datetime.datetime.utcnow() - datetime.timedelta(days=days)).isoformat()
    data = Orders(credentials=CREDS, marketplace=MP).get_orders(CreatedAfter=after).payload
    return [{"id": o["AmazonOrderId"], "date": o["PurchaseDate"], "status": o["OrderStatus"],
             "total": o.get("OrderTotal", {}).get("Amount"), "items": o.get("NumberOfItemsShipped", 0)
             + o.get("NumberOfItemsUnshipped", 0)} for o in data.get("Orders", [])]


def get_order_items(order_id: str):
    data = Orders(credentials=CREDS, marketplace=MP).get_order_items(order_id).payload
    return [{"sku": i.get("SellerSKU"), "asin": i.get("ASIN"), "title": i.get("Title"),
             "qty": i.get("QuantityOrdered"), "price": i.get("ItemPrice", {}).get("Amount")}
            for i in data.get("OrderItems", [])]


def get_inventory():
    data = Inventories(credentials=CREDS, marketplace=MP).get_inventory_summary_marketplace(details=True).payload
    return [{"sku": s.get("sellerSku"), "asin": s.get("asin"), "name": s.get("productName"),
             "fulfillable": s.get("inventoryDetails", {}).get("fulfillableQuantity"),
             "total": s.get("totalQuantity")} for s in data.get("inventorySummaries", [])]


def get_competitive_price(asin: str):
    return Products(credentials=CREDS, marketplace=MP).get_competitive_pricing_for_asins([asin]).payload


def search_catalog(keywords: str):
    """Product research: find products on Amazon by keyword."""
    data = CatalogItems(credentials=CREDS, marketplace=MP).search_catalog_items(
        keywords=keywords, includedData="summaries,salesRanks").payload
    out = []
    for item in data.get("items", [])[:10]:
        summ = (item.get("summaries") or [{}])[0]
        ranks = item.get("salesRanks") or []
        out.append({"asin": item.get("asin"), "title": summ.get("itemName"),
                    "brand": summ.get("brand"), "sales_ranks": ranks})
    return out


HANDLERS = {"get_orders": get_orders, "get_order_items": get_order_items, "get_inventory": get_inventory,
            "get_competitive_price": get_competitive_price, "search_catalog": search_catalog}
TOOLS = [
    {"name": "get_orders", "description": "List recent orders.",
     "input_schema": {"type": "object", "properties": {"days": {"type": "integer"}}}},
    {"name": "get_order_items", "description": "Get the products inside one order.",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
    {"name": "get_inventory", "description": "FBA inventory levels for all SKUs.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "get_competitive_price", "description": "Competitive pricing for an ASIN.",
     "input_schema": {"type": "object", "properties": {"asin": {"type": "string"}}, "required": ["asin"]}},
    {"name": "search_catalog", "description": "Search Amazon's catalog by keyword for product research.",
     "input_schema": {"type": "object", "properties": {"keywords": {"type": "string"}}, "required": ["keywords"]}},
]
SYSTEM = ("You are an Amazon seller assistant. Use the tools to answer with real data. "
          "Flag low stock (under 10 units), summarize sales clearly, and give practical pricing "
          "and product ideas. Never claim you changed prices or placed orders. Reply in the user's language.")


def run_agent(message: str) -> str:
    messages = [{"role": "user", "content": message}]
    for _ in range(10):
        r = client.messages.create(model=MODEL, max_tokens=2000, system=SYSTEM, tools=TOOLS, messages=messages)
        if r.stop_reason != "tool_use":
            return "".join(b.text for b in r.content if b.type == "text")
        messages.append({"role": "assistant", "content": r.content})
        results = []
        for b in r.content:
            if b.type == "tool_use":
                try:
                    out = HANDLERS[b.name](**b.input)
                except Exception as e:
                    out = {"error": str(e)}
                results.append({"type": "tool_result", "tool_use_id": b.id,
                                "content": json.dumps(out, default=str)[:20000]})
        messages.append({"role": "user", "content": results})
    return "Stopped: too many steps."


class Ask(BaseModel):
    message: str


def check(key):
    if key != API_KEY:
        raise HTTPException(401, "Bad API key")


@app.post("/ask")
async def ask(req: Ask, x_api_key: str = Header(...)):
    check(x_api_key)
    return {"reply": run_agent(req.message)}


@app.get("/orders")
async def orders(days: int = 7, x_api_key: str = Header(...)):
    check(x_api_key)
    return get_orders(days)


@app.get("/inventory")
async def inventory(x_api_key: str = Header(...)):
    check(x_api_key)
    return get_inventory()


if __name__ == "__main__":
    while True:
        print(run_agent(input("> ")))
